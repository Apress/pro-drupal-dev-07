<html>
<head>
  <title><?php print $head_title ?></title>
  <?php print $styles ?>
</head>

<body>
  <div id="container">
    <div id="header">
      <h1><?php print $site_name ?></h1>
    </div>
    
    <?php if ($sidebar_left): ?>
      <div id="sidebar-left">
        <?php print $sidebar_left ?>
      </div>
    <?php endif; ?>
    
    <div id="main">
      <h2><?php print $title ?></h2>
      <?php print $content ?>
    </div>
  
    <div id="footer">
      <?php print $footer_message ?>
    </div>
  </div>
</body>
</html>